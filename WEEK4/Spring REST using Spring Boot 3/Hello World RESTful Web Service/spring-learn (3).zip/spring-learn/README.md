# Spring Learn Project

This project, titled **Spring Learn**, is a simple Spring Boot web application created as part of the Cognizant onboarding assignment. It is intended to demonstrate the ability to set up and configure a basic Spring Boot application using Maven.

The application uses the **Spring Web** dependency to support web functionalities and **Spring Boot DevTools** for development-time features such as automatic restarts and live reloads. The project serves as a foundational template that can be extended to include controllers, services, repositories, and other typical components of a full-fledged Spring application.

It is bootstrapped using [Spring Initializr](https://start.spring.io) and built with Maven. Upon running, the application logs a simple message to verify that the application has started successfully.

This project provides hands-on experience with:
- Spring Boot application setup
- Maven-based project configuration
- Basic logging using SLF4J
- Understanding of Spring Boot’s `@SpringBootApplication` annotation and project structure

This forms the groundwork for future enhancements and web service development using Spring technologies.
