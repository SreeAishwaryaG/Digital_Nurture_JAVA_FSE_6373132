package com.cognizant.spring_learn_1;

import org.springframework.stereotype.Service;

@Service
public class AuthService {
    public boolean isValid(String username, String password) {
        return "user".equals(username) && "password".equals(password);
    }
}
