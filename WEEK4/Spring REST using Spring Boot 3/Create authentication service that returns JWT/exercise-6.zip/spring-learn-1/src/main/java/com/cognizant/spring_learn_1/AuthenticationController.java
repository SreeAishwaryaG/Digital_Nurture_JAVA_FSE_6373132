package com.cognizant.spring_learn_1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Base64;
import java.util.Map;

@RestController
public class AuthenticationController {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private AuthService authService;

    @PostMapping("/authenticate")
    public ResponseEntity<?> authenticate(@RequestHeader("Authorization") String authHeader) {
        try {
            if (authHeader != null && authHeader.startsWith("Basic ")) {
                String base64Credentials = authHeader.substring("Basic ".length());
                byte[] decoded = Base64.getDecoder().decode(base64Credentials);
                String[] userDetails = new String(decoded).split(":", 2);
                String username = userDetails[0];
                String password = userDetails[1];

                System.out.println("Username: " + username);
                System.out.println("Password: " + password);

                if (authService.isValid(username, password)) {
                    String token = jwtUtil.generateToken(username);
                    return ResponseEntity.ok(Map.of("token", token));
                } else {
                    return ResponseEntity.status(401).body(Map.of("error", "Invalid credentials"));
                }
            } else {
                return ResponseEntity.badRequest().body(Map.of("error", "Invalid Authorization header"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().body(Map.of("error", "Internal error: " + e.getMessage()));
        }
    }
}
