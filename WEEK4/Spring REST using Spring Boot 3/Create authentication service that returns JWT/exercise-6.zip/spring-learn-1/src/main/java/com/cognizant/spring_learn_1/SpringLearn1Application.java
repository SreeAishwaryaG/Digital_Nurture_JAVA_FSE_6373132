package com.cognizant.spring_learn_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringLearn1Application {
    public static void main(String[] args) {
        SpringApplication.run(SpringLearn1Application.class, args);
    }
}
